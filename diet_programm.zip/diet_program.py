import io
import random as r
from datetime import date

phrases_overly_completed = [
    'ну ты и обжора!',
    'переедаешь!',
    'да уж...',
    'у тебя есть тормоза!?',
    'остановись!',
    'как так то!',
    'вкусно наверно было (._.)'
]
phrases_completed = [
    'ура!',
    'молодец!',
    'отлично!',
    'хорошо идешь!',
    'почти переел :). Но',
    'прекрасно!',
    'ты достиг лимита калорий на сегодня, хех.',
    'надеюсь, ты сегодня больше не будешь есть, ведь'
]
phrases_uncompleted = [
    'недоедаешь!',
    'съешь чего-нибудь!',
    'ты чересчур худеешь!',
    'поешь гречки чтоль...',
    'твой лимит пока еще не достигнут, так что давай там.',
    'сегодня хорошо питаешься, удивительно...',
    'ты так скоро до цели раньше времени доберешься...'
]

while True:
    try:
        user = input('Введите ваше имя: ')
        try:
            with open(f'{'data_of_' + user + ".txt"}', 'r') as f:
                text = f.read()
                if text.split('\n')[0] == '':
                    pass
                else:
                    norm_diet_kal = int(text.split('\n')[0].split('/')[1])
                    changes = input('у вас есть изменения в росте, весе, возрасте или в образе жизни?: ')
                    if changes == 'нет':
                        break
        except FileNotFoundError:
            with open(f'{'data_of_' + user + '.txt'}', 'w') as f:
                pass
        activity = [1.2, 1.375, 1.55, 1.725, 1.9]
        norm_diet_kal = (10 * int(input('введите ваш вес:')) + 2.5 * int(
            input("введите ваш рост(в сантиметрах):")) - 5 * int(input('введите ваш возраст:')) + 5)*activity[int(input('''какая ваша активность?
(число от 1 до 5:
 1 = сидячий, без физ.активности,
 2 = лёгкие упражнения 1-3 раза в неделю,
 3 = умеренные тренировки 3-5 раз в неделю
 4 = интенсивные тренировки 6-7 раз в неделю
 5 = тяжелые физ. назгрузки, спорт или физ. работа каждый день)
 введите число:'''))-1]
        break
    except ValueError:
        print('вы ввели неправильное значение')

data_of_user = 'data_of_' + user + '.txt'
with open(data_of_user, 'r') as f:
    try:
        data = f.read().split('\n')
    except io.UnsupportedOperation:
        data = []
if data[0] == '':
    data = []
today = date.today()
today = str(today)
today_kal = 0
norm_diet_kal = int(round(norm_diet_kal))
if len(data) > 0:
    if str(today) in data[-1]:
        today_kal = int(data[0].split('/')[0])
else:
    today_kal = 0
while True:
    today_meal = input(
        '''введите Ккал продукта, который вы сегодня ели
(если не ели, то 0. Чтобы остановить, напишите stop, если вы хотите узнать кол-во съеденных за день Ккал, напишите info):''')
    print('_'*80)
    if today_meal.isdigit():
        print('команда: добавление')
        today_kal += int(today_meal)
        if today_kal < int((data[0].split('/')[1] if len(data) > 0 else norm_diet_kal)) and abs(
                today_kal - int((data[0].split('/')[1] if len(data) > 0 else norm_diet_kal))) > 20:
            with open(data_of_user, 'w') as f:
                if len(data) == 0:
                    data.append(f'{today_kal}/{norm_diet_kal}')
                else:
                    data[0] = f'{today_kal}/{data[0].split('/')[1]}'
                if str(today) in data[-1]:
                    data[-1] = str(today)
                else:
                    data.append(str(today))
                for i in range(len(data)):
                    a = f.write(f'{data[i]}\n') if i != len(data) - 1 else f.write(data[i])
            print(phrases_uncompleted[r.randint(0,
                                                len(phrases_uncompleted) - 1)] + f' вы недоели {int(data[0].split('/')[1]) - today_kal} Ккал')
            with open(data_of_user, 'r') as f:
                if len(data) > 0:
                    if str(today) in f.read().split('\n')[-1]:
                        print(f'за сегодня вы съели {data[0].split('/')[0]} из {data[0].split('/')[1]} Ккал')
                    else:
                        print(f'за сегодня вы съели 0 из {data[0].split('/')[1]} Ккал')
                else:
                    print(f'за сегодня вы съели 0 из {norm_diet_kal} Ккал')
            print("_"*80)
        if today_kal > int((data[0].split('/')[1] if len(data) > 0 else norm_diet_kal)) and abs(
                today_kal - int((data[0].split('/')[1] if len(data) > 0 else norm_diet_kal))) > 20:
            with open(data_of_user, 'w') as f:
                if len(data) == 0:
                    data.append(f'{today_kal}/{norm_diet_kal}')
                else:
                    data[0] = f'{today_kal}/{data[0].split('/')[1]}'
                if str(today) in data[-1]:
                    data[-1] = f'{str(today)} (-)'
                else:
                    data.append(f'{str(today)} (-)')
                for i in range(len(data)):
                    a = f.write(f'{data[i]}\n') if i != len(data) - 1 else f.write(data[i])
            print(phrases_overly_completed[r.randint(0,
                                                     len(phrases_overly_completed) - 1)] + f' вы переели {today_kal - int(data[0].split('/')[1])} Ккал')
            with open(data_of_user, 'r') as f:
                if len(data) > 0:
                    if str(today) in f.read().split('\n')[-1]:
                        print(f'за сегодня вы съели {data[0].split('/')[0]} из {data[0].split('/')[1]} Ккал')
                    else:
                        print(f'за сегодня вы съели 0 из {data[0].split('/')[1]} Ккал')
                else:
                    print(f'за сегодня вы съели 0 из {norm_diet_kal} Ккал')
            print("_"*80)
        if abs(today_kal - int((data[0].split('/')[1] if len(data) > 0 else norm_diet_kal))) < 20:
            with open(data_of_user, 'w') as f:
                if len(data) == 0:
                    data.append(f'{today_kal}/{norm_diet_kal}')
                else:
                    data[0] = f'{today_kal}/{data[0].split('/')[1]}'
                if str(today) in data[-1]:
                    data[-1] = f'{str(today)} (+)'
                else:
                    data.append(f'{str(today)} (+)')
                for i in range(len(data)):
                    a = f.write(f'{data[i]}\n') if i != len(data) - 1 else f.write(data[i])
            print(phrases_completed[r.randint(0, len(phrases_completed) - 1)] + ' вы выполнили суточную норму Ккал!')
            with open(data_of_user, 'r') as f:
                if len(data) > 0:
                    if str(today) in f.read().split('\n')[-1]:
                        print(f'за сегодня вы съели {data[0].split('/')[0]} из {data[0].split('/')[1]} Ккал')
                    else:
                        print(f'за сегодня вы съели 0 из {data[0].split('/')[1]} Ккал')
                else:
                    print(f'за сегодня вы съели 0 из {norm_diet_kal} Ккал')
            print("_"*80)
    if today_meal == 'info':
        print(f'команда: {today_meal}')
        with open(data_of_user, 'r') as f:
            if len(data)>0:
                if str(today) in f.read().split('\n')[-1]:
                    print(f'за сегодня вы съели {data[0].split('/')[0]} из {data[0].split('/')[1]} Ккал')
                else:
                    print(f'за сегодня вы съели 0 из {data[0].split('/')[1]} Ккал')
            else:
                print(f'за сегодня вы съели 0 из {norm_diet_kal} Ккал')
        print("_" * 80)
    elif today_meal == 'stop':
        answer = input('завершить?:')
        if answer == 'да':
            break
    elif not today_meal.isdigit():
        print("вы ввели неккоректные данные, попробуйте еще раз")